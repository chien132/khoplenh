package chien.chuyende.khoplenh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhoplenhApplication {

	public static void main(String[] args) {
		SpringApplication.run(KhoplenhApplication.class, args);
	}

}
